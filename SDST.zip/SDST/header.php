<html>
	<head>
	  <style>
		nav {
			background: white;
			padding: 2em;
			font-family: verdana;
			height: 100px;
		}
	    nav ul li a {
			text-decoration: none;
			color: black;
		}
		nav ul li {
			list-style: none;
		}
		nav ul li a:hover {
			color: white;
			font-weight: bold;
			background: black;
		}
		.left {
			width: 40%;
			float: left;
			font-size: 30px;
		}
		.right {
			width: 20%;
			float: right;
		}
	  </style>
	</head>
	<body>
		<nav>
		  <ul>
		    <li class="left"><b>Software Development Skill Test by XOMBO</b></li>
		    <div class="right">
				<li><b><a href="index.html">Home</a></b></li></br>
				<li><b><a href="index.html">Back</a></b></li>
			</div>
		  </ul>
		</nav>
	</body>
</html>