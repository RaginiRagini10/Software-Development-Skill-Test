Author: Ragini Ragini
Date: 11 June 2020
Description:
This code integrates two RESTful APIs into PHP. 
The user enters a particular id and the information related to it described in a table format. 
If the ID given is not present in any of the API, then only the API which has the correct ID is displayed, not both of them. 
Else if the ID is present in both the APIs, both of them are shown.